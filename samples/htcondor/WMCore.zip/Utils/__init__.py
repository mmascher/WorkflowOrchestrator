#! /usr/bin/env python

"""
_Utils_

Generic code that has nothing to do with WMCore, just useful
stuff to use. If this is a found snippet of code, please
credit the source.
"""

__all__ = []
