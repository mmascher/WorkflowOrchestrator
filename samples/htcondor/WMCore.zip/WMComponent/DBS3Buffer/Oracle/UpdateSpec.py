#!/usr/bin/env python
"""
_InsertSpec_

Oracle implementation of DBSBuffer3.UpdateSpec

Created on Mar 11, 2013

@author: dballest
"""

from WMComponent.DBS3Buffer.MySQL.UpdateSpec import UpdateSpec as MySQLUpdateSpec

class UpdateSpec(MySQLUpdateSpec):
    pass
