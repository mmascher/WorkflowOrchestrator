#!/usr/bin/env python
"""
_LoadBlocksByDAS_

Oracle implementation of LoadBlocksByDAS
"""




from WMComponent.DBS3Buffer.MySQL.LoadBlocksByDAS import LoadBlocksByDAS as MySQLLoadBlocksByDAS

class LoadBlocksByDAS(MySQLLoadBlocksByDAS):
    """
    _LoadBlocksByDAS_

    Untested; same as MySQL
    """
