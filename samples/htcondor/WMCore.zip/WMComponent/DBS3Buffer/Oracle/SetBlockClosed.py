#!/usr/bin/env python
"""
_DBS3Buffer.SetBlockClosed_

"""

from WMComponent.DBS3Buffer.MySQL.SetBlockClosed import SetBlockClosed as MySQLSetBlockClosed

class SetBlockClosed(MySQLSetBlockClosed):
    pass
