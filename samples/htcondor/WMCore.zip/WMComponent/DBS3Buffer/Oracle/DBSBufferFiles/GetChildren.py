#!/usr/bin/env python
"""
_GetChildren_

Oracle implementation of DBSBufferFile.GetChildren
"""




from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.GetChildren import GetChildren as MySQLGetChildren

class GetChildren(MySQLGetChildren):
    pass
