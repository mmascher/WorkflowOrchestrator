#!/usr/bin/env python
"""
_BulkHeritageParent_

Oracle implementation of DBSBufferFiles.HeritageLFNParent
"""

from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.BulkHeritageParent import BulkHeritageParent as MySQLBulkHeritageParent

class BulkHeritageParent(MySQLBulkHeritageParent):
    pass
