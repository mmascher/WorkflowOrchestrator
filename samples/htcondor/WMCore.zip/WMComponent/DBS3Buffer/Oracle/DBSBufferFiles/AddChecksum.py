#!/usr/bin/env python

"""
Oracle implementation of AddChecksum
"""





from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.AddChecksum import AddChecksum as MySQLAddChecksum

class AddChecksum(MySQLAddChecksum):
    """
    Identical to MySQL Version

    """
