#!/usr/bin/env python
"""
_SetBlock_

Oracle implementation of DBSBufferFiles.SetBlock
"""

from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.SetBlock import SetBlock as MySQLSetBlock




class SetBlock(MySQLSetBlock):
    pass
