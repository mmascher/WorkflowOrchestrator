#!/usr/bin/env python
"""
_HeritageLFNChild_

Oracle implementation of DBSBufferFiles.HeritageLFNChild
"""




from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.HeritageLFNChild import \
     HeritageLFNChild as MySQLHeritageLFNChild

class HeritageLFNChild(MySQLHeritageLFNChild):
    pass
