#!/usr/bin/env python
"""
_Delete_

Oracle implementation of Delete
"""




from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.Delete import Delete as MySQLDelete

class Delete(MySQLDelete):
    """
    _Delete_

    Oracle implementation of Delete
    """
    pass
