#!/usr/bin/env python
"""
_GetParentStatus_

Oracle implementation of DBSBufferFile.GetParentStatus
"""




from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.GetParentStatus import GetParentStatus as MySQLGetParentStatus

class GetParentStatus(MySQLGetParentStatus):
    pass
