#!/usr/bin/env python
"""

Oracle implementation of GetByID
"""




from WMComponent.DBS3Buffer.MySQL.DBSBufferFiles.GetByID import GetByID as MySQLGetByID

class GetByID(MySQLGetByID):
    """

    Oracle implementation of GetByID
    """
    pass
