#!/usr/bin/env python
"""
_CountFiles_

Oracle implementation of DBSBuffer.CountFiles
"""




from WMComponent.DBS3Buffer.MySQL.CountFiles import CountFiles as MySQLCountFiles

class CountFiles(MySQLCountFiles):
    """
    _CountFiles_

    """
    pass
