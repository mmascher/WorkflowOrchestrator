#!/usr/bin/env python
"""
_CountBlocks_

Oracle implementation of DBSBuffer.CountBlocks
"""




from WMComponent.DBS3Buffer.MySQL.CountBlocks import CountBlocks as MySQLCountBlocks

class CountBlocks(MySQLCountBlocks):
    """
    _CountBlocks_

    """
    pass
