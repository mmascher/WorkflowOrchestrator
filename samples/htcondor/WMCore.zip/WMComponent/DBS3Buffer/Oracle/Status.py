#!/usr/bin/env python
"""
_Status_

Oracle implementation of DBSBuffer.Status
"""




from WMComponent.DBS3Buffer.MySQL.Status import Status as MySQLStatus

class Status(MySQLStatus):
    pass
