"""
_MarkBlocksDeleted_

Oracle implementation of PhEDExInjector.MarkBlocksDeleted

"""

from __future__ import division
from __future__ import print_function

from WMComponent.RucioInjector.Database.MySQL.MarkBlocksDeleted import MarkBlocksDeleted as MySQLBase


class MarkBlocksDeleted(MySQLBase):
    pass
