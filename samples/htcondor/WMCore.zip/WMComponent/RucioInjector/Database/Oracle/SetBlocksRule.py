#!/usr/bin/env python
"""
_SetBlocksRule_

Oracle implementation of SetBlocksRule
"""

from __future__ import division

from WMComponent.RucioInjector.Database.MySQL.SetBlocksRule import SetBlocksRule as MySQLBase


class SetBlocksRule(MySQLBase):
    pass
