#!/usr/bin/env python
"""
_GetUninjectedFiles_

Oracle implementation on PhEDExInjector.GetUninjectedFiles.
"""
from __future__ import division

from WMComponent.RucioInjector.Database.MySQL.GetUninjectedFiles import GetUninjectedFiles as MySQLBase


class GetUninjectedFiles(MySQLBase):
    """
    _GetUninjectedFiles_

    """
    pass
