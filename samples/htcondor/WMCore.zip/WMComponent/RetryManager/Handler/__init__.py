#!/usr/bin/env python
"""
Handlers for various stages of job failure used
by the error handler
"""

__all__ = []
