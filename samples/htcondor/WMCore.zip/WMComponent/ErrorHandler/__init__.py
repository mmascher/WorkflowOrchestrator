#!/usr/bin/env python
"""
_ErrorHandler_

The ErrorHandler handles failure events with configurable
failure handlers for the three different stages (create, submit, run).


"""
__all__ = []
