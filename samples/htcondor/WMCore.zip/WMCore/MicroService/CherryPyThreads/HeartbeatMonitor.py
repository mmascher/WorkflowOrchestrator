from __future__ import (division, print_function)
from WMCore.REST.HeartbeatMonitorBase import HeartbeatMonitorBase

class HeartbeatMonitor(HeartbeatMonitorBase):

    pass
