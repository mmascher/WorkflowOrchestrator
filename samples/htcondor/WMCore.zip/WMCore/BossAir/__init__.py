#!/usr/bin/env python
"""
_BossAir_

Core libraries for the BossAir API

"""
__all__ = []
