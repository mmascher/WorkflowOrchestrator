#!/usr/bin/env python
"""
__init__

Module containing methods for daemonizing
applications.

"""
